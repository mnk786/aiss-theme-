<?php

if ( ! function_exists( 'aiss_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function aiss_setup() {
  

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );
    
    // add custom image size for theme
   /* add_image_size( 'anza_blog_grid', 360, 360, true ); //360 pixels wide and 360 pixels in height
    add_image_size( 'anza_blog_sidebar', 730, 9999 );
    add_image_size( 'anza_blog_full', 1110, 9999 );
    add_image_size( 'anza_recent_thumb', 65, 65, true );
    add_image_size( 'anza_work_thumb', 380, 285, true );
    add_image_size( 'anza_testi_thumb', 60, 60, true );
    add_image_size( 'anza_about_img', 555, 9999 );*/
    
    
	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'primary' => esc_html__( 'Primary', 'aiss' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	// Set up the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'aiss_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
	) ) );

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );
}
endif;
add_action( 'after_setup_theme', 'aiss_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */





/**
* Anza Google Fonts
*/
function aiss_google_fonts_url() {
    $fonts_url = '';

    /* Translators: If there are characters in your language that are not
    * supported by Lora, translate this to 'off'. Do not translate
    * into your own language.
    */
    $roboto = _x( 'on', 'Roboto font: on or off', 'anza' );

    /* Translators: If there are characters in your language that are not
    * supported by Open Sans, translate this to 'off'. Do not translate
    * into your own language.
    */
    $noto_sans = _x( 'on', 'Noto Sans font: on or off', 'anza' );

    if ( 'off' !== $roboto || 'off' !== $noto_sans ) {
    $font_families = array();

    if ( 'off' !== $roboto ) {
        $font_families[] = 'Roboto:300,400,500,700,900';
    }

    if ( 'off' !== $noto_sans ) {
        $font_families[] = 'Noto Sans:400,700';
    }

    $query_args = array(
        'family' => urlencode( implode( '|', $font_families ) ),
        'subset' => urlencode( 'latin,latin-ext' ),
    );

    $fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
    }

    return esc_url_raw( $fonts_url );
}    



/**
 * Setup aiss Styles and Scripts
 */
function aiss_scripts() {

    if (is_admin()) return; // don't dequeue on the backend
    
    /*Load aiss CSS*/
    wp_enqueue_style( 'aiss-style', get_stylesheet_uri() );
    
    wp_enqueue_style( 'aiss-google-fonts', aiss_google_fonts_url(), array(), null );
    wp_enqueue_style( 'style-main', esc_url( get_template_directory_uri() ).'/css/style.css' );
    wp_enqueue_style( 'bootstrap', esc_url( get_template_directory_uri() ).'/css/bootstrap.css' );
    wp_enqueue_style( 'bxslider-css', esc_url( get_template_directory_uri() ).'/css/bxslider.css' );
    wp_enqueue_style( 'font-awesome', esc_url( get_template_directory_uri() ).'/font-awesome/css/font-awesome.min.css' );
    wp_enqueue_style( 'animate', esc_url( get_template_directory_uri() ).'/css/animate.css' );


    
    
       
    /*Load aiss Scripts*/
   
    
    wp_enqueue_script( 'bootstrap', esc_url( get_template_directory_uri() ) . '/js/bootstrap.js', array(), '', true );
    
	
	
	// Load the html5 shiv.
	wp_enqueue_script( 'html5shiv"', 'https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js', array(), '3.7.2' );
	wp_script_add_data( 'html5shiv', 'conditional', 'lt IE 9' );
	
	// Load the html5 html5respond.
	wp_enqueue_script( 'html5respond"', 'https://oss.maxcdn.com/respond/1.4.2/respond.min.js', array(), '1.4.2' );
	wp_script_add_data( 'html5respond', 'conditional', 'lt IE 9' );
    
	
   // wp_enqueue_script( 'bootstrap-hover-dropdown', esc_url( get_template_directory_uri() ) . '/js/bootstrap-hover-dropdown.js', array(), '', true );


	
	wp_enqueue_script( 'bxslider', esc_url( get_template_directory_uri() ) . '/js/bxslider.js', array(), '', true );
	wp_enqueue_script( 'parallax', esc_url( get_template_directory_uri() ) . '/js/parallax.min.js', array(), '', true );
	wp_enqueue_script( 'wow', esc_url( get_template_directory_uri() ) . '/js/wow.min.js', array(), '', true );


   

  //  wp_enqueue_script( 'form-contact', esc_url( get_template_directory_uri() ) . '/js/form-contact.js', array(), '', true );
    


    wp_enqueue_script( 'scripts-main', esc_url( get_template_directory_uri() ) . '/js/scripts.js', array(), '', true );

}
add_action( 'wp_enqueue_scripts', 'aiss_scripts', 100 );

function aiss_admin_style() {
        wp_register_style( 'admin_css',  esc_url( get_template_directory_uri() ) . '/css/admin.css', false, '1.0.0' );
        wp_enqueue_style( 'admin_css' );
}
add_action( 'admin_enqueue_scripts', 'aiss_admin_style' );





function aiss_excerpt_length( $length ) {
    return 20;
}
add_filter( 'excerpt_length', 'aiss_excerpt_length', 999 );


function aiss_excerpt_more( $more ) {
	return '...';
}
add_filter('excerpt_more', 'aiss_excerpt_more');


function aiss_posts_per_page_limit( $query ) {
    global $redux_demo;
    if( !is_admin() && $query->is_main_query() && is_post_type_archive( 'projects' ) ) {
        $query->set( 'posts_per_page', $redux_demo['works_display_limit'] );
    }
}
add_action( 'pre_get_posts', 'aiss_posts_per_page_limit' );







