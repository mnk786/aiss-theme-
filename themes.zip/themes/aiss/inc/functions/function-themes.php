<?php
 /* slider function */
function aiss_slider(){
	global $post;    
	$args = array(
		'post_type'      => 'slider',
		'posts_per_page' => -1,
		'order'          =>'ASC',		
	);    
	$output = '';    
	$slider_query = new WP_Query($args);
	if( $slider_query->have_posts() ) :
	while ($slider_query->have_posts()) : $slider_query->the_post();
	$src =  wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'full', true );
	$output .= '<li><img src="'. get_template_directory_uri().'/images/transparent.png"  data-src="'.$src[0].'"> </li>';
	endwhile;
	else:	
	endif;
    //Reset Query
    wp_reset_postdata();
	return $output;
}



