<?php
require get_template_directory() . '/inc/functions/function-setup.php';
require get_template_directory() . '/inc/classes/class.walker_nav_menu.php';
require get_template_directory() . '/inc/functions/function-themes.php';