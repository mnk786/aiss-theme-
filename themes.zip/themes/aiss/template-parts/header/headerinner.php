<?php
/*
* Template part for displaying menu at header
*
* @package Anza
*
*/
global $redux_demo;
?>
<section class="inner-page-banner" style="background:url(<?php echo $redux_demo['anza-inner-background-image']['url'];?>) no-repeat top center;">
				<div class="opacity">
					<div class="container">
						<h2><?php 
							if(is_page())
                            {
                                /*esc_html_e( '', 'anza' );*/
                            }
							else
								esc_html_e( 'Blog', 'anza' );
						?></h2>
                        <?php echo anza_breadcrumbs(); ?>						
					</div> <!-- /.container -->
				</div> <!-- /.opacity -->
			</section>