<?php
/*
* Template part for displaying slider at homepage
*
* @package Anza
*
*/
global $redux_demo;
?>
<div class="anza-image-area jarallax" style="background:url(<?php echo $redux_demo['anza-background-image']['url']?>);">
    <div class="display-table">
        <div class="display-table-cell">
            <div class="container">
                <div class="row">                    
                    <?php 
                         if(isset($redux_demo['anza-background-image-cta']))						 
							echo anza_cta($redux_demo['anza-background-image-cta']);
                    ?>                    
                </div>
            </div>
        </div>
    </div>
</div>