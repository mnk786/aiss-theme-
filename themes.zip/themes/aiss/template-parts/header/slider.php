<?php
/*
* Template part for displaying slider at homepage
*
* @package Aiss
*
*/

?>
<section class="slider">
    <ul class="bx-slider" style="display: none;" >
       <?php echo aiss_slider(); ?>
    </ul>
</section>