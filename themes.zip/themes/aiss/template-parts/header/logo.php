<?php
/*
* Template part for displaying logo at header
*
* @package Anza
*
*/
global $redux_demo;


			if (has_nav_menu('primary')) 
				$logo_text_style = 'line-height:82px;';
			else
				$logo_text_style = 'line-height:50px;';
		

?>
<div class="logo">
    <a href="<?php echo esc_url( home_url( '/' ) );?>" style="<?php echo $logo_text_style;?>">        
        <?php        
        if ($redux_demo['logo_type'] == "text") { 
            echo $redux_demo['logo_text'];
        }else{
            echo anza_display_logo();
        }
        ?>
    </a>
</div>