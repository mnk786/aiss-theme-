<?php
/*
* Template part for displaying menu at header
*
* @package Anza
*
*/
global $redux_demo;
	if (!$redux_demo['anza-homepage-type'])
		return;

?>
<div class="anza-slider">            
    <?php 
    
    /*
    * include the template file for slider or background image
    */
    
    if ($redux_demo['anza-homepage-type'] == 'image')
        get_template_part( 'template-parts/header/image', 'image' );
    else        
        get_template_part( 'template-parts/header/slider', 'slider' );
    ?>
</div>