<?php
/*
* Template part for displaying testimonials section at homepage
*
* @package Anza
*
*/
global $redux_demo;
    if($redux_demo['anza-testimonails']!=1)
        return;
?>    

    <!-- START TESTIMONIAL DESIGN AREA -->
    <section id="<?php echo $redux_demo['testimonials_id'];?>" class="testimonial-area section-padding jarallax" style="background:url(<?php echo $redux_demo['testimonials_image']['url']?>);">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="section-title <?php echo $redux_demo['anza-section-style'] . ' ' . $redux_demo['anza-section-heading-style'];?>">
                        <h2><?php echo $redux_demo['testimonials_heading']?></h2>
                        <p><?php echo $redux_demo['testimonials_text']?></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="testimonial-list">
                        <?php echo anza_testimonials_column(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- / END TESTIMONIAL DESIGN AREA -->