<?php
/*
* Template part for displaying blog section at homepage
*
* @package Anza
*
*/
global $redux_demo;
    if($redux_demo['anza-blog']!=1)
        return;
?> 
<section id="<?php echo $redux_demo['blog_id'];?>" class="blog-area section-padding jarallax" style="background:url(<?php echo $redux_demo['blog_image']['url']?>);">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="section-title <?php echo $redux_demo['anza-section-style'] . ' ' . $redux_demo['anza-section-heading-style'];?>">
                         <h2><?php echo $redux_demo['blog_heading']?></h2>
                    <p><?php echo $redux_demo['blog_text']?></p>
                    </div>
                </div>
            </div>
            <div class="row blog-post-area">                
                <?php echo anza_home_page_blog_posts(3);?>                
            </div>
        </div>
    </section>