<?php
/*
* Template part for displaying team section at homepage
*
* @package Anza
*
*/
global $redux_demo;
    if($redux_demo['anza-team']!=1)
        return;
?>    
<!-- START TEAM DESIGN AREA -->
<section id="<?php echo $redux_demo['team_id'];?>" class="team-area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="section-title <?php echo $redux_demo['anza-section-style'] . ' ' . $redux_demo['anza-section-heading-style'];?>">
                   <h2><?php echo $redux_demo['team_heading']?></h2>
                        <p><?php echo $redux_demo['team_text']?></p>
                </div>
            </div>
        </div>
        <div class="row">            
            <?php echo anza_team_members();?>                        
        </div>
    </div>
</section>
<!-- / END TEAM DESIGN AREA -->