<?php
/*
* Template part for displaying contact us section at homepage
*
* @package Anza
*
*/
global $redux_demo;
    if($redux_demo['anza-contact']!=1)
        return;

if($redux_demo['contact_map']==2) { 
 get_template_part( 'template-parts/homepage/map', 'map' );
 }
?>
<section id="<?php echo $redux_demo['contact_id'];?>" class="contact-area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="section-title <?php echo $redux_demo['anza-section-style'] . ' ' . $redux_demo['anza-section-heading-style'];?>">
                    <h2><?php echo $redux_demo['contact_heading']?></h2>
                    <p><?php echo $redux_demo['contact_text']?></p>
                </div>
            </div>
        </div>
      
        <div class="row contact-form-design-area"> 
            <div class="col-md-8 col-md-offset-2">
                <div class="row contact-form-address">
                    <div class="col-md-4">
                        <div class="contact-details-list-2 clear-fix">
                            <i class="fa fa-map-marker"></i>
                            <p><?php echo $redux_demo['contact_form_address']?></p>
                        </div>
                    </div>
                    <div class="col-md-4 ">
                        <div class="contact-details-list-2 clear-fix">
                            <i class="fa fa-envelope"></i>
                            <p><?php echo $redux_demo['contact_form_email']?></p>            
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class=" contact-details-list-2 clear-fix">
                            <i class="fa fa-phone"></i>
                            <p><?php echo $redux_demo['contact_form_phone']?></p>
                        </div>
                    </div>
                </div>
            </div>    
            
            <div class="col-md-8 col-md-offset-2">
                <!-- START CONTACT FORM DESIGN AREA -->
                <div class="contact-form"> 
                   <?php echo do_shortcode('[contact-form-7 id='.$redux_demo['contact_form_id'].']');?>
                </div>
                <!-- / END CONTACT FORM DESIGN AREA -->
            </div>
            <!-- START CONTACT FORM INFOMATION DESIGN AREA -->
            
            <!-- / END CONTACT FORM INFOMATION DESIGN AREA -->
        </div>
    </div>
</section>
<!-- / END CONTACT DESIGN AREA -->


    <?php if($redux_demo['contact_map']==1) {
       get_template_part( 'template-parts/homepage/map', 'map' );  
    } ?>