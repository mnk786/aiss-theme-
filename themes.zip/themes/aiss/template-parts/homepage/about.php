<?php
/*
* Template part for displaying about us section at homepage
*
* @package Anza
*
*/
    global $redux_demo;
    if($redux_demo['anza-about-section']!=1)
        return;
    if($redux_demo['about_column']==2){        
        $about_animation = "fadeInLeft";
    } else {        
        $about_animation = "fadeInRight";
    }
?>
<section id="<?php echo $redux_demo['about_id'];?>" class="about-us-area section-padding">
    <div class="container">
        <div class="row">            
			<?php
            $col_media = '<div class="col-md-6 col-sm-12 wow '.$about_animation.'" data-wow-delay=".2s">
                <div class="about-image">'.anza_about_us_media($redux_demo['about_media_type']).'</div>
            </div>';
            $col_text = '<div class="col-md-6 col-sm-12">
                <div class="about-text">
                    <h2 class="wow fadeInDown" data-wow-delay=".2s">'.wp_kses_post($redux_demo['about_heading']).'</h2>
                    <p class="wow fadeInUp" data-wow-delay=".4s">'.wp_kses_post($redux_demo['about_text']).'</p>
                    <a href="'.esc_url($redux_demo['about_btn_url']).'" target="_blank" class="read-more wow fadeInDown" data-wow-delay=".6s">'.wp_kses_post($redux_demo['about_btn_text']).'</a>
                </div>
            </div>';
			if($redux_demo['about_column']==1)
				echo $col_media.$col_text;
			else
				echo $col_text.$col_media;
						
			?>
        </div>
    </div>
</section>