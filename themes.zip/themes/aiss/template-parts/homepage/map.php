<?php
/*
* Template part for displaying contact us section at homepage
*
* @package Anza
*
*/
global $redux_demo;

   

?>

<section class="map add_top">
                <div class="container-fluid">
                        <div class="row text-center show_hide_map">
                            <h2><?php esc_html_e('Locate us on map','anza')?></h2><i id="mapicon" class="fa fa-angle-up spinBack"></i>
                        </div>
                        <div class="row map_hide" style="display: block;">
                            <div id="map"></div>
                        </div>
                    </div>
            </section>
