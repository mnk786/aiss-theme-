<?php
/*
* Template part for displaying services section at homepage
*
* @package Anza
*
*/
    global $redux_demo;
    if($redux_demo['anza-services-section']!=1)
        return;
?>
<section id="<?php echo $redux_demo['service_id'];?>" class="service-area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="section-title <?php echo $redux_demo['anza-section-style'] . ' ' . $redux_demo['anza-section-heading-style'];?>">
                    <h2><?php echo $redux_demo['services_heading']?></h2>
                    <p><?php echo $redux_demo['services_text']?> </p>
                </div>
            </div>
        </div>
        <div class="row">
            <?php echo anza_services();?>            
        </div>
    </div>
</section>
<section id="download" class="call-to-area jarallax" style="background:url(<?php echo $redux_demo['services_cta_image']['url']?>);">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="call-to-area-text">
                    <h2><?php echo $redux_demo['services_cta_heading']?></h2>
                    <p><?php echo $redux_demo['services_cta_content']?></p>
                    <a class="smoth-scroll" href="<?php echo $redux_demo['services_cta_btn_url']?>"><?php echo $redux_demo['services_cta_btn_text']?></a>
                </div>
            </div>
        </div>
    </div>
</section>