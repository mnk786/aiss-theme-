<?php
/*
* Template part for displaying contact us section at homepage
*
* @package Anza
*
*/
global $redux_demo;
    if($redux_demo['anza-contact']!=1)
        return;

    get_template_part( 'template-parts/homepage/'.$redux_demo['anza-section-contact-style'], 'contact' );
?>