<?php
/*
* Template part for displaying work section at homepage
*
* @package Anza
*
*/
    global $redux_demo;
    if($redux_demo['anza-works']!=1)
        return;
?>

    <!-- START PORTFOLIO DESIGN AREA -->
    <section id="<?php echo $redux_demo['work_id'];?>" class="gallery section-padding">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="section-title <?php echo $redux_demo['anza-section-style'] . ' ' . $redux_demo['anza-section-heading-style'];?>">
                        <h2><?php echo $redux_demo['works_heading']?></h2>
                        <p><?php echo $redux_demo['works_text']?></p>
                    </div>
                </div>
            </div>
            
            <div class="work-inner">
                <div class="gallery-menu">
                    <?php
            /*
            * display all taxonomy of portfolio/projects
            */
            echo anza_terms_filtration('projects');
        ?>
              
					</div>

                <div class="row gallery-work grid">
                   <?php echo anza_grid_portfolio(); ?>
                </div>
                
            </div>
			<div class="loadmorebtn">
			
                    <div class="col-md-12 text-center portfolio-more  wow fadeInDown" data-wow-delay=".6s">
                        <?php echo anza_load_more_button('projects'); ?>                        
                    </div>
                </div>
				
        </div>
    </section>
    <!-- / END PORTFOLIO DESIGN AREA -->
    <!-- START COMPLETE DESIGN AREA -->
    <section class="work-statistics jarallax" style="background:url(<?php echo $redux_demo['works_stats_image']['url']?>);">
        <div class="container">
            <div class="row">      
                
                <?php echo anza_work_statistics(); ?>                
            </div>
        </div>
    </section>
    <!-- / END COMPLETE DESIGN AREA -->