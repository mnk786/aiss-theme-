<?php
/*
* Template part for displaying pricing section at homepage
*
* @package Anza
*
*/
global $redux_demo;
    if($redux_demo['anza-pricing']!=1)
        return;
?> 
<!-- START PRICING DESIGN AREA -->
<section id="<?php echo $redux_demo['pricing_id'];?>" class="pricing-area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="section-title <?php echo $redux_demo['anza-section-style'] . ' ' . $redux_demo['anza-section-heading-style'];?>">
                    <h2><?php echo $redux_demo['pricing_heading']?></h2>
                    <p><?php echo $redux_demo['pricing_text']?></p>
                </div>
            </div>
        </div>
        <div class="row">
            <?php echo anza_pricing_table(); ?>
        </div>
    </div>
</section>
<!-- / END PRICING DESIGN AREA -->