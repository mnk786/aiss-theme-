<?php
/*
* Template part for displaying services section at homepage
*
* @package Anza
*
*/
   /* global $redux_demo;
    if($redux_demo['anza-services-section']!=1)
        return;*/
?>
<section id="clients" class="service-area section-padding">

    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="section-title section-heading-center section-title-style-1">
                    <h2> <span class="firstword"> Clients </span></h2>
                    <p></p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="wow zoomIn" data-wow-duration="1s" data-wow-delay="0s" style="visibility: visible; animation-duration: 1s; animation-delay: 0s;">
                <div class="bx-wrapper" style="max-width: 1066px;">
                    <div class="bx-viewport" style="width: 100%; overflow: hidden; position: relative; height: 118px;">
                        <ul class="bxslider2" style="width: 615%; position: relative; left: -690.638px;">
                            <?php echo anza_clients(); ?>
                        </ul>
                    </div>
                </div>
        </div>
    </div>
</section>
