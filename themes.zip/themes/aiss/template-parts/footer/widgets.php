<?php
/*
* Template part for displaying menu at widgets in footer
*
* @package Anza
*
*/
    global $redux_demo;
    if($redux_demo['anza-footer-widgets']!=1 || !is_active_sidebar( 'sidebar-2' ))
        return;
?>
<div class="footer-widget">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                    <?php get_sidebar('footer'); ?>
                    </div>
                </div>
            </div>    
        </div>