<?php
/*
* Template part for displaying menu at header
*
* @package Anza
*
*/
    global $redux_demo;
    if($redux_demo['anza-scroll-to-top']!=1)
        return;
?>
<div class="scroll-to-up">
    <div class="scrollup">
        <span class="lnr lnr-chevron-up"></span>
    </div>
</div>