<?php
/*
* Template part for displaying menu at header
*
* @package Anza
*
*/
    global $redux_demo;
    if($redux_demo['anza-newsletter']!=1)
        return;
?>
<div class="footer-newsletter">
     <form method="post" enctype="multipart/form-data" name="newsletter" id="form_newsletter" action="#">
    <input type="text" name="subscribe_email" id="subscribe_email" class="form-control-newsletter" placeholder="<?php esc_html_e('Subscribe','anza');?>" />
    <input type="submit" name="submit_newsletter" id="submit_newsletter" value="<?php esc_html_e('Submit','anza');?>" />
         <label id="subscribe_email-error" class="error" for="subscribe_email" style=""></label>
         <input type="hidden" class="subscribe" name="template_path" id="template_path" value="<?php echo anza_get_wp_installation();?>">  
           <span id="newsletter-success"></span>
            <span id="newsletter-error"></span>  
    </form> 
    
</div>