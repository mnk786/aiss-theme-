<?php
/*
* Template part for displaying menu at header
*
* @package Anza
*
*/
    global $redux_demo;
    if($redux_demo['anza-socail-icons']!=1)
        return;
?>
<div class="footer-social-link">
    <?php echo anza_social_icons(); ?>
</div>