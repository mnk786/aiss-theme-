<?php
/*
* Template part for displaying preloader at startup
*
* @package Anza
*
*/
?>
<!-- START PRELOADER AREA-->
    <div class="preloader-area">
        <div class="spinner">
          <div class="cube1"></div>
          <div class="cube2"></div>
        </div>
    </div>
<!-- END PRELOADER AREA -->
