<footer>
    <div class="container">
        <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12 wow zoomIn"  data-wow-duration="1s" data-wow-offset="200">
            <h2>Contact</h2>
            <p>E-mail:	swim@aiss.ae</p>
            <p> Phone:	+971 4368 9226</p>
            <p>Fax:	+971 4368 9629</p>
            <p>Mobile:	+971 556 014 549</p>
            <p>Office 2204 Al Shafar Tower 1</p>
            <p>TECOM Al Thanyah 1 Dubai - U.A.E.</p>
            <p>P.O. Box: 333959, DUBAI - U.A.E.</p>
        </div>
        <div class="col-lg-4 col-md-4 col-sm-3 col-xs-12  wow zoomIn" data-wow-duration="1s" data-wow-offset="300">
            <a href="#" class="logo"><img src="<?php echo get_template_directory_uri() ?>/images/transparent.png"  data-src="<?php echo get_template_directory_uri() ?>/images/bottom-logo.png" class="img-responsive"></a>
        </div>
        <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 wow zoomIn" data-wow-duration="1s" data-wow-offset="200">
            <h2>Map</h2>
            <img src="<?php echo get_template_directory_uri() ?>/images/transparent.png"  data-src="<?php echo get_template_directory_uri() ?>/images/map.png"  class="img-responsive map  " >
        </div>
        <div class="clearfix"></div>
    </div>
    <div class="bottom-nav">
        <ul>
            <li><a href="#">HOME</a> </li>
            <li><a href="#">SWIM SCHOOLS </a> </li>
            <li><a href="#">AUSTSWIM COURSES</a> </li>
            <li><a href="#">SPORTS SERVICES</a> </li>
            <li><a href="#">SCHOOL SPORTS</a> </li>
        </ul>

    </div>
    <a href="#">
        <div class="copy">
            <div class="container">
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <p>© 2018 aiswimschools.com, All rights reserved.</p>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <p class="company">Designed and Developed by <span> AdviceTech</span></p>
                </div>
            </div>
        </div>
    </a>

</footer>
<?php wp_footer();?>
</body>
</html>