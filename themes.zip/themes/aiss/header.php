<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php wp_title(''); ?></title>

    <?php wp_enqueue_script("jquery"); ?>
<?php wp_head(); ?>
</head>
<body class="<?php if(basename($_SERVER["PHP_SELF"]) != 'index.php') echo 'inner-body'; ?>" >