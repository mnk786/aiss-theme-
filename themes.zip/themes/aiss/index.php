<?php get_header();?>

  <?php get_template_part('template-parts/header/menu', 'menu'); ?>
  <?php get_template_part('template-parts/header/slider', 'slider');?>


    <section class="box ">
        <div class="container">
            <div class="main-box one wow slideInLeft" data-wow-duration="1s" data-wow-offset="10">

                <a href="">
                    <img src="<?php echo get_template_directory_uri() ?>/images/Button-1.jpg" alt="" class="img-responsive" />
                </a>

            </div>
            <div class="main-box two wow slideInRight" data-wow-duration="1s" data-wow-offset="200">
                <a href="">
                    <img src="<?php echo get_template_directory_uri() ?>/images/Button-2.jpg" alt="" class="img-responsive" />
                </a>
            </div>
            <div class="main-box three wow slideInRight" data-wow-duration="1s" data-wow-offset="300">
                <a href="">
                    <img src="<?php echo get_template_directory_uri() ?>/images/Button-3.jpg" alt="" class="img-responsive" />
                </a>
            </div>
            <div class="content wow zoomIn" data-wow-duration="1s" data-wow-offset="300">
                <h2>Welcome to<br>
                    Australian International Swim Schools</h2>
                <p>AISS offers a comprehensive range of innovative aquatic education services and programs based on extensive international experience in the provision of world class aquatic education. We offer a wide range of classes from baby programs and learn to swim, through to advanced coaching and adult learn to swim. See our programs page for a full list of classes offered.</p>
                <a href="#" class="read"><span>Read More</span></a>
                <div class="clearfix"></div>
            </div>

        </div>
    </section>
    <section class="fitness">
        <div class="container">
            <div class="second-content wow slideInLeft" data-wow-duration="1s" data-wow-offset="300">
                <h2>Triathalon and<br>
                    Fitness Squad</h2>
                <p>It’s all about how hard you TRI.</p>

                <p>07:00 am (Sunday - Tuesday - Thursday)
                    06:00 am (Monday - Wednesday)</p>

                <p>Instructor: Svetlana Blazevic</p>
                <a href="#" class="read"><span>Read More</span></a>
            </div>
        </div>
        <div class="clearfix"></div>
    </section>
    <section class="swimming">
        <div class="container">
            <div class="content wow zoomIn" data-wow-duration="1s" data-wow-offset="300">
                <h2>Learn to Swim and<br>
                    Swimming Programs on offer</h2>
                <p>Swimming and Learn to Swim Programs available are listed on the left. Not all are available at all venues at present due to the venues facilities or time constraints</p>

                <p>More information on these programs will be available on the website soon.</p>

                <p>In the meantime, contact us for more details.</p>
                <a href="#" class="read"><span>Read More</span></a>
            </div>
            <div class="second-content wow zoomIn" data-wow-duration="1s" data-wow-offset="300">
                <h2>Swimming Grading<br>
                    and Levels</h2>
                <p>All lessons are 30 Min - as the children do not use attached flotation devices the classes are more demanding than many children have experienced previously. Once they progress the lessons increase in length when they start to swim longer distances and their fitness and stamina </p>
                <a href="#" class="read"><span>Read More</span></a>
            </div>
            <div class="clearfix"></div>
        </div>
    </section>
    <section class="summer">
        <div class="container">
            <div class="second-content wow slideInRight" data-wow-duration="1s" data-wow-offset="300">
                <h2>Summer and School<br>
                    holiday Programs</h2>
                <p>Swim programs for kids and adults - click on a program for more info</p>
                <ul>
                    <li> AISS Spring Intensive Programs</li>
                    <li>AISS Summer Intensive Programs</li>
                    <li>AISS Summer Intensive Programs - Adults</li>
                    <li>School Holiday Swim Programs</li>
                </ul>
                <a href="#" class="read"><span>Read More</span></a>
            </div>
        </div>
    </section>
    <section class="company">
        <div class="container">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 wow zoomIn" data-wow-duration="1s" data-wow-offset="300">
                <div class="outer"> <div class="img"> <img src="<?php echo get_template_directory_uri() ?>/images/transparent.png"  data-src="<?php echo get_template_directory_uri() ?>/images/compny1.png" class=" img1"></div></div>
                <h2>AISS Company Profile</h2>
                <p>Australian International Sports Services (AISS) is an Australian founded Dubai-based Aquatic Education and Swimming Services Company.
                    The Managing Director is Kirk Marks, an Australian trained teacher qualified in physical</p>
                <a href="#" class="read green"><span>Read More</span></a>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 wow zoomIn" data-wow-duration="1s" data-wow-offset="300">
                <div class="outer"><div class="img"><img src="<?php echo get_template_directory_uri() ?>/images/transparent.png"  data-src="<?php echo get_template_directory_uri() ?>/images/compny2.png"  class="img2"></div></div>
                <h2>Work with AISS</h2>
                <p>Due to continuing expansion we are seeking applications from AUSTSWIM Qualified Swimming Teachers for immediate start in several of our locations in the UAE. We are also recruiting for positions in Qatar.</p>
                <a href="#" class="read blue"><span>Read More</span></a>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 wow zoomIn" data-wow-duration="1s" data-wow-offset="300">
                <div class="outer"><div class="img"> <img src="<?php echo get_template_directory_uri() ?>/images/transparent.png"  data-src="<?php echo get_template_directory_uri() ?>/images/compny3.png"  class="img3"></div></div>
                <h2>AISS System</h2>
                <p>We will at all times liaise with and work directly with your designated school staff.
                    AISS ensures that participation in all of the swimming programs offered is a positive experience, that participation is fun and that</p>
                <a href="#" class="read"><span>Read More</span></a>
            </div>
        </div>
    </section>
<?php get_footer(); ?>